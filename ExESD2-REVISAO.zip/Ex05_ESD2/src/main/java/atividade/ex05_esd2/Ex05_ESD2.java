package atividade.ex05_esd2;

public class Ex05_ESD2 {

    public static void ordenarDecrescente(int[] v) {
        for (int i = 0; i < v.length - 1; i++) {
            int maiorIndice = i;

            // Procura o maior elemento no trecho ainda não ordenado
            for (int j = i + 1; j < v.length; j++) {
                if (v[j] > v[maiorIndice]) {
                    maiorIndice = j;
                }
            }

            // Troca o elemento da posição atual pelo maior encontrado
            int aux = v[i];
            v[i] = v[maiorIndice];
            v[maiorIndice] = aux;
        }
    }

    public static void main(String[] args) {
        int[] v = {5, 2, 8, 1, 9, 3};

        ordenarDecrescente(v);

        System.out.print("Vetor em ordem decrescente: ");
        for (int num : v) {
            System.out.print(num + " ");
        }
    }
}
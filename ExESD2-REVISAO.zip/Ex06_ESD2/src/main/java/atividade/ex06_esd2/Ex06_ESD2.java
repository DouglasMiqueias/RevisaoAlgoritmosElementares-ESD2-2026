package atividade.ex06_esd2;

public class Ex06_ESD2 {

    public static void mergeSort(int[] v, int inicio, int fim) {
        if (inicio < fim) {
            int meio = (inicio + fim) / 2;

            mergeSort(v, inicio, meio);
            mergeSort(v, meio + 1, fim);

            intercalar(v, inicio, meio, fim);
        }
    }

    public static void intercalar(int[] v, int inicio, int meio, int fim) {
        int[] aux = new int[fim - inicio + 1];

        int i = inicio;
        int j = meio + 1;
        int k = 0;

        while (i <= meio && j <= fim) {
            if (v[i] <= v[j]) {
                aux[k] = v[i];
                i++;
            } else {
                aux[k] = v[j];
                j++;
            }
            k++;
        }

        while (i <= meio) {
            aux[k] = v[i];
            i++;
            k++;
        }

        while (j <= fim) {
            aux[k] = v[j];
            j++;
            k++;
        }

        for (int x = 0; x < aux.length; x++) {
            v[inicio + x] = aux[x];
        }
    }

    public static void main(String[] args) {
        int[] v = {8, 3, 1, 7, 0, 10, 2};

        mergeSort(v, 0, v.length - 1);

        System.out.print("Vetor ordenado: ");
        for (int num : v) {
            System.out.print(num + " ");
        }
    }
}
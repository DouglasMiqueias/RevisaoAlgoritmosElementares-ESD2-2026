/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package atividade.ex03_esd2;

/**
 *
 * @author mique
 */
public class Ex03_ESD2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

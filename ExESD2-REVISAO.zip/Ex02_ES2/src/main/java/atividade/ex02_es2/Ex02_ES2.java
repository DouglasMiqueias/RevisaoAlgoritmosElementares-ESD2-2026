package atividade.ex02_es2;

public class Ex02_ES2 {

    public static int[] inserirOrdenado(int x, int[] v) {
        int[] novoVetor = new int[v.length + 1];
        int i = 0;

        // Copia para o novo vetor todos os elementos menores que x
        while (i < v.length && v[i] < x) {
            novoVetor[i] = v[i];
            i++;
        }

        // Insere x na posição correta
        novoVetor[i] = x;

        // Copia o restante dos elementos
        while (i < v.length) {
            novoVetor[i + 1] = v[i];
            i++;
        }

        return novoVetor;
    }

    public static void main(String[] args) {
        int[] v = {1, 3, 5, 7, 9};
        int x = 6;

        int[] resultado = inserirOrdenado(x, v);

        System.out.print("Vetor após inserção: ");
        for (int num : resultado) {
            System.out.print(num + " ");
        }
    }
}
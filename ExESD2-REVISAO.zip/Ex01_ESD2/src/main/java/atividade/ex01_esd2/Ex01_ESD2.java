package atividade.ex01_esd2;

public class Ex01_ESD2 {

    public static boolean estaEmOrdemCrescente(int[] v) {
        for (int i = 0; i < v.length - 1; i++) {
            if (v[i] > v[i + 1]) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        int[] v1 = {1, 2, 3, 4, 5};
        int[] v2 = {1, 2, 2, 3, 4};
        int[] v3 = {1, 3, 2, 4, 5};
        int[] v4 = {5, 4, 3, 2, 1};
        int[] v5 = {7};

        System.out.println(estaEmOrdemCrescente(v1)); // t
        System.out.println(estaEmOrdemCrescente(v2)); // t
        System.out.println(estaEmOrdemCrescente(v3)); // f
        System.out.println(estaEmOrdemCrescente(v4)); // f
        System.out.println(estaEmOrdemCrescente(v5)); // t
    }
}